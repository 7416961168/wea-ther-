import React from "react";
import "./styles.css";

export default function Footer() {
  return (
    <div className="footer">
      Coded by
      <a href="https://www.instagram.com/amanvalpanesar/">Amanpreet Panesar</a>
    </div>
  );
}
