import React from "react";
import "./styles.css";

export default function Weather() {
  return (
    <div className="displayBox">
      <section className="heading">
        <h1 id="citySearch">London, UK</h1>
        <h4 id="today">Monday, 06 September</h4>
        <span className="time"> 12:54 PM </span>
      </section>
      <div className="container" id="weatherDescription">
        <div className="row">
          <div className="col-6 temperature">
            Today's Forecast
            <h2 id="currentTemperature">22°C</h2>
          </div>
          <div className="col-6 temperature">
            <ul className="detail">
              <li id="humidity">Humidity</li>
              <li id="windSpeed">Wind Speed</li>
              <li id="description">Description</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
