import React from "react";
import "./styles.css";

export default function Searchbar() {
  return (
    <div className="container">
      <form className="search-form">
        <div className="row">
          <div className="col">
            <input
              type="search"
              className="searchInput"
              placeholder="Enter City Name"
            />
            <button className="button">Search</button>
          </div>
        </div>
      </form>
    </div>
  );
}
