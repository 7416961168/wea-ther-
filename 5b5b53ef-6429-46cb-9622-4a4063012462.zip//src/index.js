import React from "react";
import ReactDOM from "react-dom";

import Searchbar from "./Searchbar";
import Weather from "./Weather";
import Footer from "./Footer";

import "./styles.css";

function App() {
  return (
    <div className="App">
      <Searchbar />
      <hr />
      <Weather />
      <hr />
      <Footer />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
